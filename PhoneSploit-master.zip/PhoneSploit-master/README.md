# PhoneSploit
#### A tool for remote ADB exploitation in Python3.

![STARS](https://img.shields.io/github/stars/aerosol-can/PhoneSploit?style=social) 
![FORKS](https://img.shields.io/github/forks/aerosol-can/PhoneSploit?style=social)
![COMMIT](https://img.shields.io/github/last-commit/aerosol-can/PhoneSploit)
![SIZE](https://img.shields.io/github/repo-size/aerosol-can/PhoneSploit)
[![Sponser](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/G2G7MS0SJ)

# Features
* Access Shell
* Screen record victim device
* Screenshot a picture on victim device
* Pull folders from victim device
* Turn victim device off
* Uninstall an app
* Show real time log of victim device
* Dump system info
* List all apps on victim
* Run an app
* Port Forwarding
* NetStat
* Grab wpa_supplicant
* Turn WiFi On/Off
* Show Mac/Inet
* __Remove Password__
* Extract apk from app  
* Use Keycode   
* Get Battery Status
* Get Current Activity
* Send file/folder from PC to Phone

# Author's Note

#### Don't do Bad Things ya Guys :kissing::v:

> You can find open ports on the Internet [here at Shodan](https://www.shodan.io/search?query=android+debug+bridge+product%3A”Android+Debug+Bridge”)

# YouTube Videos
<br>
<br>

### Connecting device via ADB
<br>

[![Connecting device via ADB](https://img.youtube.com/vi/OlhCAX1qBQo/0.jpg)](http://www.youtube.com/watch?v=OlhCAX1qBQo)

<br>
<br>

### Exploiting ADB via PhoneSploit

<br>

[![Exploiting ADB via PhoneSploit](https://img.youtube.com/vi/ONHxcGMdkM0/0.jpg)](http://www.youtube.com/watch?v=ONHxcGMdkM0)

<br>
<br>
<br>

# HOW TO INSTALL ON WINDOWS
```
git clone https://github.com/aerosol-can/PhoneSploit
```
extract adb.rar to the phonesploit directory 
```
cd PhoneSploit
pip install colorama
phonesploit.py
```

# HOW TO INSTALL ON Linux
```
apt install adb
git clone https://github.com/aerosol-can/PhoneSploit
cd PhoneSploit
pip3 install colorama
python3 phonesploit.py
```

# HOW TO INSTALL ON macOS
First of all, install [brew](https://brew.sh)
```
brew install git python@3
git clone https://github.com/aerosol-can/PhoneSploit
cd PhoneSploit
python3 -m pip install colorama
python3 phonesploit.py
```

# IF ADB NOT FOUND
```shell
sudo apt update

sudo apt install android-tools-adb android-tools-fastboot

```

<br>
<br>

# PhoneSploit Framework Disclaimer

> Usage of the PhoneSploit Framework for attacking targets without prior mutual consent is illegal.

> It is the end user's responsibility to obey all applicable local, state, federal, and international laws.

> Developers assume no liability and are not responsible for any misuse or damage caused by this program.

